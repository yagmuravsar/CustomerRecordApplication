package tr.com.customerrecord.CustomerRecord;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerRecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRecordApplication.class, args);
	}
}
